Pack downloaded from Freesound
----------------------------------------

"Click"

This Pack of sounds contains sounds by the following user:
 - lebaston100 ( https://freesound.org/people/lebaston100/ )

You can find this pack online at: https://freesound.org/people/lebaston100/packs/12197/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this Pack
-------------------

  * 192283__lebcraftlp__click.wav
    * url: https://freesound.org/s/192283/
    * license: Attribution 4.0
  * 192282__lebcraftlp__click.wav
    * url: https://freesound.org/s/192282/
    * license: Attribution 4.0
  * 192281__lebcraftlp__click.wav
    * url: https://freesound.org/s/192281/
    * license: Attribution 4.0
  * 192280__lebcraftlp__click.wav
    * url: https://freesound.org/s/192280/
    * license: Attribution 4.0
  * 192279__lebcraftlp__click.wav
    * url: https://freesound.org/s/192279/
    * license: Attribution 4.0
  * 192278__lebcraftlp__click.wav
    * url: https://freesound.org/s/192278/
    * license: Attribution 4.0
  * 192277__lebcraftlp__click.wav
    * url: https://freesound.org/s/192277/
    * license: Attribution 4.0
  * 192276__lebcraftlp__click.wav
    * url: https://freesound.org/s/192276/
    * license: Attribution 4.0
  * 192275__lebcraftlp__click.wav
    * url: https://freesound.org/s/192275/
    * license: Attribution 4.0
  * 192274__lebcraftlp__click.wav
    * url: https://freesound.org/s/192274/
    * license: Attribution 4.0
  * 192273__lebcraftlp__click.wav
    * url: https://freesound.org/s/192273/
    * license: Attribution 4.0
  * 192272__lebcraftlp__click.wav
    * url: https://freesound.org/s/192272/
    * license: Attribution 4.0
  * 192271__lebcraftlp__click.wav
    * url: https://freesound.org/s/192271/
    * license: Attribution 4.0
  * 192270__lebcraftlp__click.wav
    * url: https://freesound.org/s/192270/
    * license: Attribution 4.0


